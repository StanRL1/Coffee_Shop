package com.exam.model.entity.enums;

public enum CategoryName {
    COFFEE,CAKE,DRINK,OTHER;
}
